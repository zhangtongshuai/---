$(function() {
    // var token ='eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjMwNTg0OCwiaXNzIjoiaHR0cDovL3Yuaml1ZGluZ2ZhbnlpLmNvbS9zdWIvbG9naW4iLCJpYXQiOjE1MjUzMzAwODEsImV4cCI6MTUyNTkzNDg4MSwibmJmIjoxNTI1MzMwMDgxLCJqdGkiOiJjeUdVTmc5Tnp3ZkhIVjFqIn0.Bx3iBnEFstuMQS9ZemWm92zzVtqmHkOPDLWA6zZD6aQ';
    // var api ="http://192.168.1.145";
    var token = window.localStorage.getItem("token");
    var api = "";

    $.ajax({
        type: 'get',
        url: api + '/api/tuto/adm/lesson?token=' + token,
        dataType: 'json',
        success: function (re) {
            //console.log(re);
            var teacher=re.data;
            var html=template('tpl-teacher-list-info',teacher);
            document.getElementById('teacher-list-info').innerHTML=html;
        }
    });
});