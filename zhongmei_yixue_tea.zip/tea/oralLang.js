var url =window.location.href;
var appid = 'wx9c1363226b0be64a';
var apii = 'https://vedio.jiudingfanyi.com';
if(localStorage.hasOwnProperty("token")){
    if(localStorage.getItem("token")==''){
        window.location = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+appid+"&redirect_uri="+apii+"/wx/login&response_type=code&scope=snsapi_userinfo&state="+url+"#wechat_redirect";
    }else{
        var myDate = new Date();
        var mynewDay =myDate.getTime();
        if(localStorage.getItem("expire")*1000 <(mynewDay - 3600000)){
            window.location = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+appid+"&redirect_uri="+apii+"/wx/login&response_type=code&scope=snsapi_userinfo&state="+url+"#wechat_redirect";
        }
    }
}else{
    window.location = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+appid+"&redirect_uri="+apii+"/wx/login&response_type=code&scope=snsapi_userinfo&state="+url+"#wechat_redirect";
}
